<?php
/**
 * Created by Eguana.
 * User: Brian
 * Date: 2020-06-28
 * Time: 오후 11:46
 */

namespace CJ\CatalogProduct\Logger;

class Logger extends \Monolog\Logger
{

}
