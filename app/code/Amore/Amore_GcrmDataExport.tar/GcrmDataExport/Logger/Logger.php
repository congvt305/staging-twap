<?php
/**
 * @author Eguana Team
 * @copyriht Copyright (c) 2021 Eguana {http://eguanacommerce.com}
 * Created by PhpStorm
 * User: adeel
 * Date: 29/6/21
 * Time: 12:55 PM
 */
namespace Amore\GcrmDataExport\Logger;

use Monolog\Logger as LoggerAlias;

/**
 * Logger New Instance
 *
 * Class Logger
 */
class Logger extends LoggerAlias
{

}
